var express = require('express');
var router = express.Router();

var todos;

router.get('/', function(req, res) {
    res.render('todo', { title: '할 일 목록 정리'});
  });

router.route('/api/todo')
.get(function(req, res) {
    console.log("GET /api/todo");
    //res.send(JSON.stringify(todo));
    res.send(JSON.stringify("GET /api/todo"));
})
/* POST /api /todo */
.post(function(req,res) {
    console.log('Post: ');
    var todo = { }
    todos.push(todo);
    return res.send(todos);
})
.put(function(req,res) {
    return res.json({title:todo.title, message : 'Todo updated!'});
})
;

router.route('/api/todo/:id')
.get(function(req,res) {
    console.log("GET /api/todo/" + req.params.id);
    res.send('Request by ID : ' + req.params.id);
})
.delete(function(req, res){
    return res.json( {message:"ID(" + req.params.id + ") Successfully deleted!"});
});

module.exports = router;
